# Handoff: Trend Check — rediseño corporativo

## Overview
Trend Check es una herramienta de análisis que compara la tendencia pasada de **sell-out (EPOS)** y **sell-in (REAS)** con el **forecast de sell-in** (Q2, Q3, Q4, FY) por product line. Para cada línea, un motor clasifica el caso (gap × trayectoria), calcula una "zona recomendada" y marca los puntos de forecast que quedan dentro, cerca o fuera. El rediseño es **visual**: la lógica del motor, el playbook, el parser de Excel y los datos embebidos **no cambian**.

## About the Design Files
`Trend Check.html` es la **referencia de diseño en HTML** y también es el archivo funcional original con el nuevo estilo aplicado. Si existe un codebase de destino, recrea el diseño con sus patrones y librerías. Si no existe, basta con aplicar este archivo tal cual o portarlo a una app ligera (por ejemplo, Vite con JS o TS).

- El archivo pesa unos 900 KB porque lleva SheetJS (xlsx.js) embebido en línea para leer el Excel sin conexión. En un proyecto real, usa `xlsx` desde npm.
- **La lógica de negocio debe conservarse al pie de la letra.** Eso incluye:
  - `PLAYBOOK`, `analyse()` y `parseRows()`;
  - `pct()`, `chart()` y `arrow()`;
  - los parámetros del motor.

## Fidelity
**High-fidelity.** Colores, tipografía, espaciados y estados son finales. **Solo modo claro:** el usuario pidió explícitamente eliminar el modo oscuro, así que no hay que reintroducirlo.

## Screens / Views
Es una sola página y tiene estos bloques, de arriba abajo:

### 1. App bar + hero (franja azul marino)
- **Fondo:** `#13294b`, ancho completo, `padding-bottom: 84px` (las tarjetas del resumen se solapan sobre ella).
- **Línea superior:** 4px, mitad `#1f5fae` (SO) y mitad `#d9772b` (SI), con un gradiente de corte duro al 50%.
- **Fila de marca:** contenedor de `max-width: 1240px` y `padding: 18px 24px 0`, en flex space-between.
  - **Logotipo:** 34×34, radio 4px, fondo blanco, texto "TC" en IBM Plex Mono 600 13px, color `#13294b`.
  - **Título:** "Trend Check", IBM Plex Sans 600 18px, blanco.
  - **Subtítulo:** "Fuente · {archivo · pestaña}", 12.5px, `rgba(255,255,255,.62)`. El nombre del archivo va en blanco y 500, sin salto de línea.
  - **Botón "Cargar Excel":** fondo blanco, texto `#13294b`, 13px 500, padding 8px 14px, radio 4px; en hover el fondo pasa a `#e8edf5`. Abre un input de archivo oculto (`.xlsx/.xlsm/.xls`).
- **Cabecera del hero:** `padding: 36px 24px 0`, en flex wrap space-between y alineada abajo.
  - **Eyebrow:** "RESUMEN DE CARTERA", Plex Mono 11px, `letter-spacing .14em`, mayúsculas, `rgba(255,255,255,.55)`.
  - **Título:** "Tendencia vs. forecast por product line", Plex Sans 600 26px, `letter-spacing -0.015em`, blanco.
  - **Meta (`#heroMeta`):** cuatro datos calculados: nº de product lines, nº con puntos fuera, nº sin info y total value. El número va en Plex Mono 500 15px blanco y la etiqueta en 12.5px `rgba(255,255,255,.62)`, con gap de 8px × 28px.

### 2. Resumen de cartera (tarjetas)
- **Rejilla:** `repeat(auto-fill, minmax(210px, 1fr))`, gap 12px y `margin-top: -52px` para montarse sobre la franja.
- **Tarjeta (`button.ov`):**
  - Fondo blanco, borde 1px `#dde2e9`, radio 6px, padding 14px 16px.
  - Sombra `0 4px 14px rgba(19,41,75,.08)`; columna flex con gap de 10px.
  - **Arriba:** rango "01"… (Plex Mono 12px `#6b7584`) y badge de estado a la derecha.
  - **Nombre:** Plex Sans 600 13.5px `#13294b`, `min-height: 2.6em`.
  - **Barra de peso:** 4px de alto; pista `#edf0f4`, relleno `#13294b` con ancho igual a total/TOTAL.
  - **Pie:** total value a la izquierda y % de cartera a la derecha, Plex Mono 11.5px `#4a5566`.
  - **Hover:** borde `#8b95a3` y `translateY(-1px)`.
  - **Seleccionada (`aria-pressed=true`):** borde `#13294b` más `box-shadow 0 0 0 1px #13294b, 0 6px 18px rgba(19,41,75,.14)`.
- **Orden:** total value de mayor a menor.

### 3. Nota "Cómo leerlo" y parámetros
- **Nota:** tarjeta blanca, radio 4px, en rejilla `auto | 1fr`.
  - **Etiqueta:** "CÓMO LEERLO", Plex Mono 500 11px, mayúsculas, `#13294b`.
  - **Texto:** 13px `#4a5566`.
- **Parámetros:** un `<details>` con summary "Parámetros del motor" y la pista "Prototipo · ajustables" alineada a la derecha.
  - El chevron es CSS y rota 45° al abrir.
  - Al abrir, la rejilla de inputs va sobre `#f7f8fa`, en `auto-fit minmax(200px,1fr)`.
  - Inputs de 100px de ancho con foco `outline 2px rgba(31,95,174,.25)`.

### 4. Barra de herramientas (sticky)
- `position: sticky; top: 0`, fondo `rgba(243,245,248,.96)` con `backdrop-filter: blur(6px)` y borde inferior.
- Etiqueta "PRODUCT LINE" (Plex Mono 11px, mayúsculas) seguida de un select con un `min-width` de 280px.
- **Leyenda:** Sell-out, Sell-in, Zona recomendada, ● Quarter ◆ FY, Dentro, Cerca y Fuera. Cada ítem va en `nowrap`.

### 5. Bloque por product line (`article.line`)
- **Título (h2):** 21px 600 `#13294b`.
  - Antes del nombre va el rango "01" en Plex Mono 13px `#1f5fae`, con un divisor derecho de 1px.
  - Después, "Total value **17,433** · 42% de cartera" en 13px `#6b7584`, con el número en Plex Mono, y el badge de estado.
- **Panel:** dos columnas `1.15fr | 1fr`, gap 16px; pasa a una columna por debajo de 900px.
- **Tarjeta:** blanca, borde `#dde2e9`, radio 6px, padding 20px, `overflow: hidden`.
- **Columna izquierda:**
  - **Cabecera del caso:** a sangre dentro de la tarjeta (`margin: -20px -20px 0; padding: 16px 20px`) y teñida según el tipo de gap:
    - depleción: `#fbf1f0`;
    - equilibrio: `#f1f4f8`;
    - sobre-stock: `#f4f1f9`;
    - sin caso: `#f7f8fa`.
  - Contenido de la cabecera:
    - **Pill del tipo:** Plex Mono 11px, mayúsculas, radio 3px, texto blanco. Fondos: depleción `#b33a3a`, equilibrio `#4f6076`, sobre-stock `#6a4c9c`, sin caso `#9aa3af`.
    - **Código "SO↑ / SI↓":** 18px 600, `nowrap`.
    - **Nombre del caso:** 14px `#4a5566`.
    - **Pill "Peor caso":** fondo `#fbeeee`, texto `#c23b3b`.
  - **KPIs:** dos celdas en rejilla 1fr/1fr con fondo `#f7f8fa`, borde `#edf0f4` y radio 4px. La etiqueta va en Plex Mono 11px mayúsculas `#6b7584`; el valor en Plex Mono 500 19px `#13294b`.
    - "Gap 6m (SO − SI)" en pp.
    - "Puntos fuera de zona" como "n / 4".
  - **Gráfico SVG** (ver abajo).
- **Columna derecha:**
  - **Filas "Qué pasa" y "Acción":** etiqueta de 120px en Plex Mono 11px mayúsculas y separadores de 1px.
  - **"Dónde poner los puntos":** caja con fondo `#edf6f1`, borde `#cfe6d9` y radio 4px. La etiqueta va en `#23834f` y debajo aparece "Zona calculada: x a y".
  - **Tabla de puntos:**
    - Columnas: Punto, Forecast YoY, Distancia a zona, Estado. Todas las celdas en `nowrap`.
    - Cabecera sobre `#f7f8fa`, en Plex Mono 10.5px mayúsculas.
    - Números en tabular-nums (Plex Sans, no mono).
    - Hover de fila en `#f7f8fa`.
    - Estado: ✓ Dentro `#23834f`, ! Cerca `#a87400`, ✕ Fuera `#c23b3b`, – Sin zona `#6b7584`.
  - **Avisos:**
    - Normal: fondo `#fdf6e6`, borde `#f1e2bb`.
    - Crítico: fondo `#fbeeee`, borde `#efd2d2`.
    - Ambos con radio 4px y 12.5px.

### Gráfico (SVG, viewBox 660×420)
- **Zona de forecast:** a la derecha del divisor (x=282) va un rectángulo de fondo `#f7f8fa`, dibujado antes de la rejilla.
- **Cabeceras:** "TENDENCIA · PASADO" y "FORECAST SELL-IN · FUTURO", en Plex Mono 10px, `letter-spacing 1.2`, `#6b7584`.
- **Rejilla:** líneas `#edf0f4`; la línea del 0% es discontinua `5 4` en `#8b95a3`.
- **Zona recomendada:**
  - Relleno `rgba(44,138,90,.11)` con bordes discontinuos `4 3` en `#2c8a5a`.
  - Si la zona está abierta por un lado, se dibuja un gradiente que se desvanece.
- **Flechas (cambio pedido explícitamente por el usuario):**
  - Grosor del cuerpo `sw = 6` y semiancho de la punta `hw = 14`.
  - **La base de 12m es una marca corta** de ancho `(sw+3)*2 = 18px`, alto 3 y rx 1.5. Antes medía 40px y el usuario pidió que fuera más corta.
  - Colores: SO `#1f5fae`, SI `#d9772b`.
- **Puntos:**
  - Quarters: círculo r=7.5. FY: rombo k=11.
  - Trazo blanco de 2px, color según estado.
- **Tooltip:** blanco, radio 4px, sombra `0 6px 20px rgba(19,41,75,.14)`, 12px.

## Interactions & Behavior
- **Tarjeta del resumen:** un clic filtra la vista a esa línea; un segundo clic sobre la misma vuelve a "Todas". Está sincronizada con el select.
- **Select de product line:** filtra la vista y hace scroll al inicio de la página.
- **Parámetros:** cualquier `input` recalcula todo al momento (`render()`).
- **Cargar Excel:**
  - Busca la pestaña `AFTER`; si no existe, usa la primera.
  - Mapea las columnas por cabecera: PRODUCT LINE*, TOTAL VALUE, EPOS 6M/12M, REAS 6M/12M, Q2, Q3, Q4 y FY*.
  - Si hay un error, muestra un `alert`.
- **Tooltips:** se activan con hover sobre cualquier `[data-tip]` (flechas y puntos) y siguen al cursor.
- **Transiciones:** 0.12s en hover de botones y tarjetas; 0.15s en el chevron de los parámetros.

## State Management
- `DATA`: `{ source, fyLabel, lines[] }`. Viene embebido y se reemplaza al cargar un Excel.
- `selected`: `'all'` o el nombre de una línea.
- `TOTAL`: suma de total value, que se usa para las barras de peso y el % de cartera.
- Los parámetros del motor (`pEq`, `pB`, `pSlackQ`, `pSlackFY`, `pLow`) se leen de los inputs.

## Design Tokens
**Colores**
- Fondo de página `#f3f5f8`; superficie `#ffffff`; superficie suave `#f7f8fa`.
- Borde `#dde2e9`; rejilla `#edf0f4`; eje `#8b95a3`.
- Navy `#13294b`; navy hover `#1d3a66`.
- Texto: `#16202e` (primario), `#4a5566` (secundario), `#6b7584` (atenuado).
- Series: SO `#1f5fae`, SI `#d9772b`.
- Zona recomendada `#2c8a5a`, con fondo `rgba(44,138,90,.11)`.
- Estados: bien `#23834f`, aviso `#d69a12`, crítico `#c23b3b`, n/d `#9aa3af`.
- Fondos suaves: bien `#edf6f1`, aviso `#fdf6e6`, crítico `#fbeeee`.

**Tipografía**
- Familias: IBM Plex Sans (400, 500, 600) para UI y texto; IBM Plex Mono (400, 500) para etiquetas en mayúsculas, rangos, cifras de KPI y meta. Ambas de Google Fonts.
- Etiquetas en mayúsculas: Mono 10.5–11px, `letter-spacing .06–.08em` (eyebrow .14em).
- Escala: cuerpo 14/1.5; etiquetas y metadatos de 12 a 13px; nombres de tarjeta 13.5px; título del hero 26px; título de línea 21px.

**Radios:** 3px en badges y pills; 4px en botones, inputs, cajas y KPIs; 6px en tarjetas.

**Sombras**
- Tarjeta: `0 1px 2px rgba(19,41,75,.05), 0 1px 3px rgba(19,41,75,.06)`.
- Tarjeta del resumen: `0 4px 14px rgba(19,41,75,.08)`.

**Espaciado:** contenedor de `max-width 1240px`, padding lateral 24px; separación entre bloques de línea 32px; padding de tarjeta 20px; gaps de 12–16px.

## Assets
Ninguno. No hay imágenes; los iconos son caracteres (✓ ✕ ● ◆ ↑ ↓) o CSS.

## Files
- `Trend Check.html`: diseño final y funcional, con CSS en `<style>`, el markup de la cabecera y la lógica en `<script>`. SheetJS va embebido en el primer `<script>`.
